### Hexlet tests and linter status:
[![Actions Status](https://github.com/WeibHai/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/WeibHai/python-project-49/actions)

<a href="https://codeclimate.com/github/WeibHai/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aef6e394a343b6a61ba0/maintainability" /></a>

asciinema-1 https://asciinema.org/a/8g8bjpPSqAHy88BUarxqnA5e0

asciinema-2 (calc games) https://asciinema.org/a/rK2jPoY79ZAWlcDM9ullmIzbc

asciinema-3 (gcd games) https://asciinema.org/a/nS3D83CcJBHzTcF4UYLOdeEqi

asciinema-4 (progression games) https://asciinema.org/a/DYUG5HGzYQzXXovDC1KiV85Xb

asciinema-5 (prime games) https://asciinema.org/a/RBp86w9148EPN67KhGG1XBN7L

