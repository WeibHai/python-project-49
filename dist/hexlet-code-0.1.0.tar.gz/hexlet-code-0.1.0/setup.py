# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Pack of five games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/WeibHai/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/WeibHai/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/WeibHai/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aef6e394a343b6a61ba0/maintainability" /></a>\n\nThe \'\'python-project-49\'\' project consists of 5 games:\n1. "Even Check" - during the game a number will be presented, the user will be prompted to determine if the number presented is even or odd?\n2. "Calculator" - an arithmetic problem will be presented, the user will be asked to solve it.\n3. "GCD" - in this game the user will be asked to determine the greatest common divisor of two numbers.\n4. "Arithmetic progression" - during the game the user will be asked to find out the missing number in the arithmetic progression.\n5. "Is it a prime number?" - the user will be presented with a number, his task is to determine whether it is prime.\nAfter launching one of the games, the user will have 1 attempt and 3 questions.\n\nSystem requirements: python version 3.8 or higher\n\nInstallation process:\n\n<p>1. Print on command line - \'python3 -m pip install --user dist/*.whl.\'</p>\n<p>https://asciinema.org/a/Q1FQSwhm6eM4sPRIGFQWYvHaz"</p>\n\n<p>2. Choose one of five games:</p>\n\n<p>"Even Check" - brain-even</p>\n<p>https://asciinema.org/a/8g8bjpPSqAHy88BUarxqnA5e0</p>\n<p>"GCD" - brain-gcd</p>\n<p>https://asciinema.org/a/nS3D83CcJBHzTcF4UYLOdeEqi</p>\n<p>"Calculator" - brain-calc</p>\n<p>https://asciinema.org/a/rK2jPoY79ZAWlcDM9ullmIzbc</p>\n<p>"Arithmetic progression" - brain-progression</p>\n<p>https://asciinema.org/a/DYUG5HGzYQzXXovDC1KiV85Xb</p>\n<p>"Is it a prime number?" - brain-prime.</p>\n<p>https://asciinema.org/a/RBp86w9148EPN67KhGG1XBN7L</p>\n',
    'author': 'Mark',
    'author_email': 'proskurina-1956@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/WeibHai/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
